# Website Handoff — HyphaMind (Bundle 2025-10-31)

This package gives your coding assistant and writer everything needed to align the site with the whitepaper and recent architecture updates.

## Core Grammar (site‑wide)
**ROOT → VALVE → CLASP → TRACE → MIRE → SCAR → COMPOST → ECHO → SPORE**  
Use this loop iconography and language where helpful; link to a glossary page when ready.

## Content Map (produced in this project)
- Cards (Markdown body only, no front matter):  
  - `site/cards/about-founder.md` — founder background, pointers to Labs.  
  - `site/cards/personal-ethos.md` — first‑person ethos, bullets, ECHO call.  
  - `site/cards/labs.md` — pilots + pipeline; feedback to whitepaper.  
  - `site/cards/contact.md` — channels + collab protocol.

- Long‑form docs (from prior bundles; recommended paths):  
  - `docs/chorus/about-founder-full.md`  
  - `docs/chorus/2025-10-30-vibe-harness-emergence.fieldnote.md`  
  - `docs/chorus/2025-10-30-why-it-happened-now.md`  
  - `docs/chorus/2025-10-30-on-rupture-and-rooting.fieldnote.md`  
  - `docs/chorus/2025-10-30-field_resonance.card.md`  
  - `docs/chorus/collective-onboarding.md`  
  - `docs/chorus/provenance-covenant.md`  
  - `docs/chorus/contact-collab.md`  
  - `docs/verticals/2025-11-multiomics-vertical.proposal.md`  
  - `docs/co-creation-whitepaper.md` (current master copy)

- Metrics bundle (optional site section):  
  - Singularity Metric spec + scripts; renders `S_index.png`: use for a “Horizon” card.

## Cross‑links (add in templates/nav)
- About → Labs  
- Labs → Whitepaper, Provenance Covenant, Collective Onboarding  
- Personal Ethos → Contact, Labs  
- Contact → Labs (smoke test protocol)

## Provenance & Accessibility
- Pair public claims with open‑web **and** Wayback links (see Provenance Covenant).  
- Avoid images with text‑only meaning; offer alt text; use semantic headings.

## Visual Language
- Low‑key, modern: ample whitespace, soft grids, earcon icons for **allow/deny/refrain/spore**.  
- Treat the loop like a timeline chip; minimal color use; animation only where meaningful (e.g., REFRAIN pulse).

## Future Pages (optional)
- **Glossary:** definitions of all primitives.  
- **ECHO Reflex Architecture:** MIRE→SCAR→COMPOST listener design note.  
- **SPORE Verify:** public verifier + reader‑recoverability FAQ.

## Build Hints
- Provide a `make site-smoke` that checks links and Wayback captures.  
- Add a GH Action to regenerate the Singularity Metric monthly (optional).

— End of handoff.
